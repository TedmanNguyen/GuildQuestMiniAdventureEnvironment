package models;

import models.tiles.Tile;
import models.tiles.TileCharacter;

public abstract class Grid {
    private Tile[][] grid;
    private Characters p1, p2;
    private int rows, cols;

    public Grid(int rows, int cols, Characters p1, Characters p2) {
        this.rows = rows;
        this.cols = cols;
        this.grid = new Tile[rows][cols];
        this.p1 = p1;
        this.p2 = p2;
        initializeGrid();
        placeCharacters();
    }

    private void initializeGrid() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                final int row = i;
                final int col = j;
                final TileCharacter emptyChar = new TileCharacter(' ');
                grid[i][j] = new Tile() {
                    {
                        // initialize currentCharacter and position safely
                        currentCharacter = new TileCharacter(emptyChar);
                        this.position = new Position(row, col);
                    }

                    @Override
                    public void stepOn(Characters c) {
                        currentCharacter.updateCharacter(c.tileCharacter());
                    }

                    @Override
                    public void stepOff() {
                        currentCharacter.updateCharacter(emptyChar);
                    }

                    @Override
                    public String toString() {
                        return currentCharacter.toString();
                    }
                };
            }
        }
    }

    private void placeCharacters() {
        if (p1 != null) {
            int x = p1.getXPosition();
            int y = p1.getYPosition();
            if (inBounds(y, x)) {
                grid[y][x].stepOn(p1);
            }
        }
        if (p2 != null) {
            int x = p2.getXPosition();
            int y = p2.getYPosition();
            if (inBounds(y, x)) {
                grid[y][x].stepOn(p2);
            }
        }
    }

    private boolean inBounds(int row, int col) {
        return row >= 0 && row < rows && col >= 0 && col < cols;
    }

    public void displayGrid(){
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < cols; j++){
                System.out.print(grid[i][j].toString());
            }
            System.out.println();
        }
    }

}